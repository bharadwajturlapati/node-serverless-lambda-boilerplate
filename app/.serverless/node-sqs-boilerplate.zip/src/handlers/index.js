module.exports = {
    hello: require('./helloword')
}